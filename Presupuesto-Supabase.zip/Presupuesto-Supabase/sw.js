// Service worker: abre la app sin conexión. No intercepta las llamadas a Supabase.
var V = 'presupuesto-sb-v1';
var SHELL = ['./', 'index.html', 'config.js', 'manifest.webmanifest', 'icon-180.png', 'icon-192.png', 'icon-512.png'];
var CDN = ['cdnjs.cloudflare.com', 'cdn.jsdelivr.net'];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(V).then(function (c) { return c.addAll(SHELL); }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener('activate', function (e) {
  e.waitUntil(
    caches.keys()
      .then(function (ks) { return Promise.all(ks.filter(function (k) { return k !== V; }).map(function (k) { return caches.delete(k); })); })
      .then(function () { return self.clients.claim(); })
  );
});
self.addEventListener('fetch', function (e) {
  var r = e.request;
  if (r.method !== 'GET') return;
  var u = new URL(r.url);
  if (u.origin === location.origin) {
    e.respondWith(
      fetch(r).then(function (res) {
        var copy = res.clone();
        caches.open(V).then(function (c) { c.put(r, copy); });
        return res;
      }).catch(function () {
        return caches.match(r).then(function (m) { return m || caches.match('index.html'); });
      })
    );
  } else if (CDN.indexOf(u.hostname) >= 0) {
    e.respondWith(
      caches.match(r).then(function (m) {
        return m || fetch(r).then(function (res) {
          var copy = res.clone();
          caches.open(V).then(function (c) { c.put(r, copy); });
          return res;
        });
      })
    );
  }
});
