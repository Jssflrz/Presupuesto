# Mi presupuesto con Supabase (datos en la nube, multiusuario)

## Archivos
index.html, config.js, sw.js, manifest.webmanifest, icon-*.png, supabase/setup.sql

## 1. Crear el proyecto en Supabase
1. Entra a supabase.com, crea una cuenta y un proyecto nuevo (plan Free). Guarda la contraseña de la base de datos.
2. Menú SQL Editor > New query. Pega TODO el contenido de `supabase/setup.sql` y pulsa Run. Debe decir "Success".
3. Project Settings > API Keys: copia la **Project URL** y la clave **Publishable** (sb_publishable_...). Si tu proyecto solo muestra la clave antigua "anon", sirve igual.
   No uses nunca la "secret" ni la "service_role" en esta app.

## 2. Configurar el correo (Authentication)
- Authentication > URL Configuration: en **Site URL** pon la dirección de tu app (https://TU-USUARIO.github.io/presupuesto/) y agrégala también en **Redirect URLs**. Sin esto, los enlaces de confirmación y de recuperar clave no vuelven a tu app.
- Authentication > Sign In / Providers > Email: por defecto exige confirmar el correo. Para uso personal puedes dejarlo así (más seguro) o desactivar "Confirm email" para entrar sin confirmar.
- Los correos de prueba de Supabase tienen un límite bajo de envíos por hora. Si necesitas más, configura un SMTP propio en Authentication > SMTP.

## 3. Poner tus datos en config.js
Abre `config.js` y reemplaza la URL y la clave publishable por las tuyas.

## 4. Publicar (igual que antes, en GitHub)
Sube los archivos al repositorio `presupuesto` reemplazando los anteriores: index.html, config.js, sw.js, manifest.webmanifest y los 3 íconos. La carpeta `supabase` es solo para ti, no hace falta subirla.
Cierra la app y ábrela dos veces con internet para que tome la versión nueva.

## 5. Primer uso e importar tus registros
1. Abre la app (con el mismo ícono o dirección de antes), toca **Crear cuenta** y confirma tu correo si te lo pide. Luego entra.
2. **Si usas la app instalada en este mismo teléfono:** al entrar, la app detecta los datos guardados en el dispositivo y te ofrece **Subir mis datos a mi cuenta**. Es la forma más fácil de importar.
3. **Si tus datos están en otra versión** (la de Claude, por ejemplo): allí ve a Presupuesto > Exportar y copia el texto. En la app nueva, Presupuesto > Respaldo > pega el texto > Importar. Pide confirmación porque reemplaza lo que haya en tu cuenta.
4. Entra desde cualquier otro dispositivo con el mismo correo y clave: verás lo mismo.

## Varios usuarios
- Cada persona toca **Crear cuenta** con su correo. Cada una ve y edita solo sus datos: la base de datos lo impone con seguridad por filas (RLS), no solo la pantalla.
- Cualquiera que conozca tu dirección puede registrarse. Si no quieres cuentas ajenas, en Authentication > Sign In / Providers desactiva "Allow new users to sign up" después de crear las cuentas que necesites (puedes crear usuarios manualmente en Authentication > Users).

## Cómo funciona la sincronización
- Cada usuario tiene una fila con todos sus datos. Cada cambio se guarda en la nube a los pocos segundos; arriba verás "Guardado en la nube".
- Sin internet puedes seguir abriendo la app con tu última copia local; los cambios quedan pendientes y se envían al volver la conexión.
- Si editas desde dos dispositivos a la vez, gana el que guardó primero: el otro recibe el aviso "Se actualizó desde otro dispositivo" y carga la versión de la nube. Repite tu último cambio.

## Muy importante: plan gratuito
- Supabase **pausa los proyectos gratuitos tras 7 días sin actividad**. La app deja de funcionar hasta que reactivas el proyecto manualmente desde el panel (los datos no se pierden). Si abres la app al menos una vez por semana, no se pausa. El plan Pro (25 USD/mes) no pausa y tiene respaldos diarios.
- El plan gratuito no incluye respaldos automáticos: exporta tu copia desde Presupuesto de vez en cuando.

## Diferencias con la versión anterior
- El usuario y clave locales se reemplazaron por correo y clave de Supabase. Ya no hay cierre automático por inactividad: la sesión queda abierta hasta que toques **Cerrar sesión**.
- El botón "Análisis con Claude" no aparece fuera de Claude. El análisis automático sí funciona.
- Los datos que ya estaban en el teléfono no se borran; quedan como copia local.
